import ProductPrototype from "./ProductPrototype";

export default function App() {
  return <ProductPrototype />;
}
