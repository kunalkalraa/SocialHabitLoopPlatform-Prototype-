import React, { useState } from "react";

// Clickable single-file prototype for a "novel product idea" generator & mini-POC.
// - Built as a single React component using Tailwind utility classes.
// - Contains a 3-screen flow: Home (idea brief), Prototype Canvas (interactive mockups), Feedback (save/send).
// - Navigation is fully clickable and simulates interactions; replace mock images/text with real assets as needed.

export default function ProductPrototype() {
  const [screen, setScreen] = useState("home");
  const [idea, setIdea] = useState({
    title: "AuraShelf — context-aware product discovery",
    subtitle:
      "A tiny physical+digital shelf that surfaces hyper-local, time-aware product ideas and micro-experiences.",
    bullets: [
      "Detects room context (lighting, sound signature, calendar cues) and suggests one micro-experience or product.",
      "Pairs a small e-ink shelf tag + phone app for low-distraction discovery.",
      "Monetizable via maker marketplace and micro-subscriptions for curated ideas.",
    ],
    featureCards: [
      {
        id: 1,
        title: "Context Capture",
        desc: "Passive sensing (light, noise, calendar) + optional manual input to form idea triggers.",
      },
      {
        id: 2,
        title: "Micro-Experiences",
        desc: "One-minute, low-friction product-use suggestions (e.g., instant tea ritual, 3-min desk stretch).",
      },
      {
        id: 3,
        title: "Maker Marketplace",
        desc: "Independent creators publish kits and micro-services tied to triggers.",
      },
    ],
  });

  const [selectedFeature, setSelectedFeature] = useState(null);
  const [notes, setNotes] = useState("");

  return (
    <div className="min-h-screen bg-gray-50 p-6 font-sans text-gray-800">
      <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden grid grid-cols-1 md:grid-cols-3">
        {/* Side nav / preview column */}
        <aside className="md:col-span-1 p-6 bg-gradient-to-b from-white to-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold">
              A
            </div>
            <div>
              <h3 className="text-lg font-semibold">Prototype</h3>
              <p className="text-xs text-gray-500">Clickable product concept</p>
            </div>
          </div>

          <nav className="space-y-2">
            <button
              className={`w-full text-left px-4 py-2 rounded-lg ${
                screen === "home"
                  ? "bg-indigo-50 border border-indigo-100"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setScreen("home")}
            >
              Home — Brief
            </button>
            <button
              className={`w-full text-left px-4 py-2 rounded-lg ${
                screen === "canvas"
                  ? "bg-indigo-50 border border-indigo-100"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setScreen("canvas")}
            >
              Prototype Canvas
            </button>
            <button
              className={`w-full text-left px-4 py-2 rounded-lg ${
                screen === "feedback"
                  ? "bg-indigo-50 border border-indigo-100"
                  : "hover:bg-gray-50"
              }`}
              onClick={() => setScreen("feedback")}
            >
              Feedback & Export
            </button>
          </nav>

          <div className="mt-6">
            <h4 className="text-sm font-semibold text-gray-600">
              Quick actions
            </h4>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                onClick={() => alert('Saved to "My Concepts" (simulated).')}
                className="px-3 py-2 rounded-lg border text-sm"
              >
                Save
              </button>
              <button
                onClick={() => alert("Shared to Slack / Email (simulated).")}
                className="px-3 py-2 rounded-lg border text-sm"
              >
                Share
              </button>
            </div>
          </div>

          <div className="mt-6 text-xs text-gray-500">
            Tip: click "Prototype Canvas" to explore screens and interactive
            elements.
          </div>
        </aside>

        {/* Main area */}
        <main className="md:col-span-2 p-6">
          {screen === "home" && (
            <section>
              <header className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold">{idea.title}</h1>
                  <p className="text-sm text-gray-600 mt-1">{idea.subtitle}</p>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500">Stage</div>
                  <div className="mt-1 inline-block px-3 py-1 text-sm bg-yellow-50 rounded-full border">
                    Concept
                  </div>
                </div>
              </header>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {idea.bullets.map((b, idx) => (
                  <div key={idx} className="p-4 rounded-lg border bg-white">
                    <p className="text-sm">{b}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold">Key features</h3>
                <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4">
                  {idea.featureCards.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => {
                        setSelectedFeature(f);
                        setScreen("canvas");
                      }}
                      className="text-left p-4 border rounded-lg hover:shadow-sm bg-white"
                    >
                      <h4 className="font-semibold">{f.title}</h4>
                      <p className="text-xs text-gray-500 mt-1">{f.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </section>
          )}

          {screen === "canvas" && (
            <section>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">Prototype Canvas</h2>
                <div className="text-sm text-gray-500">
                  Interactive mock screens — click items
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Mock device */}
                <div className="p-4 bg-gray-50 rounded-lg border">
                  <div className="border rounded-lg overflow-hidden bg-white shadow-sm">
                    <div className="p-4 flex items-center justify-between border-b">
                      <strong className="text-sm">AuraShelf App</strong>
                      <span className="text-xs text-gray-400">
                        Simulated device
                      </span>
                    </div>

                    <div className="p-4">
                      <div className="mb-4">
                        <div className="text-xs text-gray-500">
                          Current context
                        </div>
                        <div className="mt-1 text-sm font-medium">
                          Quiet afternoon · Warm light
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="text-xs text-gray-500">
                          Suggested micro-experience
                        </div>
                        <div className="mt-2 p-3 rounded-lg border bg-indigo-50">
                          <h4 className="font-semibold">3-min Tea Ritual</h4>
                          <p className="text-xs mt-1">
                            A quick sensory break: steep a special tea, perform
                            a 1-minute breathing exercise, rearrange a tiny
                            shelf item.
                          </p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() =>
                            alert('"Start experience" triggered (simulated).')
                          }
                          className="px-3 py-2 rounded-lg border"
                        >
                          Start
                        </button>
                        <button
                          onClick={() => {
                            setNotes("I like the tea ritual — addictive!");
                            setScreen("feedback");
                          }}
                          className="px-3 py-2 rounded-lg bg-indigo-600 text-white"
                        >
                          Save Feedback
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Design cards / interaction tools */}
                <div className="p-4 bg-white rounded-lg border">
                  <h4 className="font-semibold">Design Kit</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Quick knobs you can toggle to simulate variants
                  </p>

                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm">Discovery Mode</label>
                      <select className="border rounded px-2 py-1 text-sm">
                        <option>Passive</option>
                        <option>Active</option>
                        <option>Scheduled</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between">
                      <label className="text-sm">Tone</label>
                      <div className="text-sm">Playful</div>
                    </div>

                    <div className="flex items-center justify-between">
                      <label className="text-sm">Delivery</label>
                      <div className="flex gap-2">
                        <button className="px-2 py-1 border rounded text-xs">
                          Phone
                        </button>
                        <button className="px-2 py-1 border rounded text-xs">
                          Shelf Tag
                        </button>
                        <button className="px-2 py-1 border rounded text-xs">
                          Email
                        </button>
                      </div>
                    </div>

                    <div className="mt-4">
                      <h5 className="text-sm font-semibold">
                        Selected feature
                      </h5>
                      {selectedFeature ? (
                        <div className="mt-2 p-3 border rounded">
                          <div className="font-medium">
                            {selectedFeature.title}
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            {selectedFeature.desc}
                          </div>
                          <div className="mt-3 flex gap-2">
                            <button
                              onClick={() =>
                                alert(
                                  "Prototype: open flow for " +
                                    selectedFeature.title
                                )
                              }
                              className="px-3 py-1 border rounded text-sm"
                            >
                              Open Flow
                            </button>
                            <button
                              onClick={() =>
                                alert("Exported feature spec (simulated)")
                              }
                              className="px-3 py-1 bg-indigo-600 text-white rounded text-sm"
                            >
                              Export
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-2 text-xs text-gray-500">
                          Click a feature card from Home to load here.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick prototype footer */}
              <div className="mt-6 flex items-center justify-between">
                <div className="text-xs text-gray-500">
                  Prototype interactions are simulated — press Save to capture
                  notes.
                </div>
                <div>
                  <button
                    onClick={() => setScreen("home")}
                    className="px-3 py-2 rounded-lg border mr-2"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setScreen("feedback")}
                    className="px-3 py-2 rounded-lg bg-indigo-600 text-white"
                  >
                    Go to Feedback
                  </button>
                </div>
              </div>
            </section>
          )}

          {screen === "feedback" && (
            <section>
              <h2 className="text-xl font-bold">Feedback & Export</h2>
              <p className="text-sm text-gray-500 mt-1">
                Leave notes or export the idea as a one-pager.
              </p>

              <div className="mt-4">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Your notes for the idea..."
                  className="w-full h-32 border rounded p-3 text-sm"
                />

                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => {
                      alert(
                        "Exported idea as PDF (simulated) — contents:\n" +
                          idea.title +
                          "\n" +
                          idea.subtitle +
                          "\nNotes:\n" +
                          notes
                      );
                    }}
                    className="px-4 py-2 rounded-lg bg-green-600 text-white"
                  >
                    Export One-pager
                  </button>
                  <button
                    onClick={() => {
                      setNotes("");
                      alert("Feedback cleared.");
                    }}
                    className="px-4 py-2 rounded-lg border"
                  >
                    Clear
                  </button>
                </div>
              </div>

              <div className="mt-6 text-xs text-gray-500">
                Actions: Copy idea text, Save to workspace, or Request a deeper
                wireframe.
              </div>
            </section>
          )}
        </main>
      </div>

      <footer className="max-w-6xl mx-auto mt-6 text-xs text-gray-500 text-center">
        This is a clickable prototype (single-file). Replace content and assets
        to tailor the idea.
      </footer>
    </div>
  );
}
